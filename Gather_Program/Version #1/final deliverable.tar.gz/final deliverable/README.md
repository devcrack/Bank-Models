open terminal in this path and execute using the command : "./exe"

Call to lanimfe to get the Codes :)

