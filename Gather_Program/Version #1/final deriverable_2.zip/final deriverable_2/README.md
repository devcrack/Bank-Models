Basic Use: 
           Open terminal in this path and execute using the command : "./blds"
           and follow the structions.


If you wish you can modify several options about the calculates. Just edit the files:
                                                                            -options_HS.txt
                                                                            -options_SS.txt
                                                                            -Yuk_options.txt


